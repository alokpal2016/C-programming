#include<stdio.h>
void main()
{
	int p,t,r;
	float i;
	printf("Eneter the principle amount, time and rate of interest\n");
	scanf("%d%d%d",&p,&t,&r);
	i=(float)p*t*r/100;
	printf("S.I=%0.2f\n",i);
}
