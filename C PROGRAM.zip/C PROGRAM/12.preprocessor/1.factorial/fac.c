#include <stdio.h>
#define Factorials(num){ \
  int fact=1;\
  if(num==0){ \
	 fact=1; \
 } else \
{	for (int i = num; i >0; i--) { \
  fact=fact*i; \
} \
} printf("The factorials of %d is: %d\n",num,fact); \
}


int main()
{
int num;
printf("Please enter the number for factorials: ");
scanf("%d",&num);
Factorials(num);
return 0;
}
