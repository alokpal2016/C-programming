#include <stdio.h>
#include <stdlib.h>

#define circumference(r) (2*3.141*(r))
#define COUNT 5
void main(){
    int radius;
    float c;

    #if(COUNT > 1)
    {
    printf("NULL : %d\n", NULL );
    printf("EXIT_SUCCESS : %d\n", EXIT_SUCCESS );
    printf("EXIT_FAILURE : %d\n", EXIT_FAILURE );
    printf("RAND_MAX : %d\n", RAND_MAX );
    printf("File Name : %s\n", __FILE__ );
    printf("DATE : %s\n", __DATE__ );
    printf("Line : %d\n\n", __LINE__ );
    }
    #else
        printf("Enter a number\n");
    #endif

    printf("Enter the radius of circle\n");
    scanf("%d", &radius);
    c=circumference(radius);
    printf("Circumference of Circle = %f\n",c);

    return 0;
}
