#include<string.h>
int any(char s1[],char s2[])
{
  int i,j,len1,len2;
  len1=strlen(s1);
  len2=strlen(s2);
  for(i=0;i<len1;i++)
  {
    for(j=0;j<len2;j++)
    {
      if(s1[i]==s2[j])
        return i+1;
    }
  }
  return -1;
}
