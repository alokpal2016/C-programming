#include<stdio.h>
#include<string.h>
#include"any.h"
int main()
{
  char s1[10],s2[10];
  int location;
  printf("enter the string s1 and s2:");
  scanf("%s%s",&s1,&s2);
  printf("string is:%s\n%s\n",s1,s2);
  location=any(s1,s2);
  if(location==(-1))
  {
    printf("not char match:");
  }
  else
  {
    printf("char found at location:%d",location);
  }
}
