int any(char s1[],char s2[]);
