#include<stdio.h>
#include<stdio_ext.h>
#include<string.h>
void main()
{
  char a[100],b[100];
  char *p,temp,*q;
  int i =0,k=0;
  p=a;
  *p=0;
  printf("\n enter a string and \n");
do
  {
    gets(p);
    i=strlen(a);
    p=a+i;
    *p='\n';
    __fpurge(stdin);
    p++;
  }while(*(p-2)!='$');
  *(p-2)='\0';
p=a[0];
i=0;
while(a[i])
{
  if(a[i]=='\n')
  {
    b[k]='\\';
    k++;
    b[k]='n';
    k++;
    i++;
  }

  else if(a[i]=='\t')
  {
    b[k]='\\';
    k++;
    b[k]='t';
    k++;
    i++;
  }
  else
  {
    b[k]=a[i];
    i++;
    k++;
  }
}
b[k]='\0';
printf("\n%s",b);
printf("\n");
}
