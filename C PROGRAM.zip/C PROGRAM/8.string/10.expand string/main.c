#include<stdio.h>
#include <stdio_ext.h>
void main()
{
  char str[100],ch=0;
int i=0;
  printf("enter the string\n");
while(ch!='$')
{
__fpurge(stdin);
ch=getchar();

str[i]=ch;
i++;
}
int j=0;
while(j<=i)
{
  putchar(str[j]);
  j++;
}
}
