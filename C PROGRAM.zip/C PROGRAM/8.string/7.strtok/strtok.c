#include<stdio.h>
#include<string.h>
void strtoken(char s1[],char s2[])
{
  int i,j,len1,len2;
  len1=strlen(s1);
  len2=strlen(s2);
  for(i=0;i<len1;i++)
  {
    for(j=0;j<len2;j++)
    {
      if(s1[i]==s2[j])
         s1[i]=' ';
    }
  }
  printf("%s",s1);
}
