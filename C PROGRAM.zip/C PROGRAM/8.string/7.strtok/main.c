#include<stdio.h>
#include<string.h>
#include"strtok.h"
int main()
{
  char s1[10],s2[10];
  printf("enter the strings:\n");
  scanf("%s%s",s1,s2);
  printf("the string is:\ns1=%s\ns2=%s\n",s1,s2);
  strtoken(s1,s2);
}
