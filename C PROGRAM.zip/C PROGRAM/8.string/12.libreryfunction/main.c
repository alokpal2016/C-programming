#include<stdio.h>
#include<string.h>
#include"function.h"
int main()
{
  char s1[10],s2[10],s3[10];
  printf("enter the two string:\n");
  scanf("%s%s",s1,s2);
  printf("s1=%s\ns2=%s\n",s1,s2);
  //strrev(s1);
  strcopy(s1,s2);
  printf("%s\n",s1);
  //strcaat(s1,s2);
  //printf("%s\n",s1);
  if((strcmp(s1,s2))==0)
  printf("string is same:\n");
  else
  printf("strinf is not match");


}
