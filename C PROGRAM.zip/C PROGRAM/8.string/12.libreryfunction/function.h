void strcopy(char s1[],char s2[]);
void strcaat(char s1[],char s2[]);
//void strrev(char s[]);
int strcamp(char s1[],char s2[]);
