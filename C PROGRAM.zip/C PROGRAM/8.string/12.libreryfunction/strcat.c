#include<stdio.h>
#include<string.h>
void strcaat(char s1[],char s2[])
{
  int i=0,j=0,len1,len2;
  len1=strlen(s1);
  len2=strlen(s2);
  for(i=0;i<len2;i++)
      if(s[i]=='\0')
      {
        for(j=i;j<len1+len2-1;j++)
        {
          s1[j]=s2[j];
        }
      }
}
