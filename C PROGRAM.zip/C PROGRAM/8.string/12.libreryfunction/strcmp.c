#include<stdio.h>
#include<string.h>
int stracmp(char s1[],char s2[])
{
  int i,len1;
  len1=strlen(s1);
  for(i=0;i<len1;i++)
  {
   if(s1[i]==s2[i])
    {
         return 0;

    }
  else
    {
      return -1;

    }
  }
}
