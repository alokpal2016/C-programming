#include<string.h>
void strcopy(char s1[],char s2[])
{
  int i=0,j=0,len1,len2;
  len1=strlen(s1);
  len2=strlen(s2);
  for(i=0;i<len2;i++)
  {
       s1[i]=s2[i];

  }
  for(j=i;j<len1;j++)
      s1[j]='\0';
}
