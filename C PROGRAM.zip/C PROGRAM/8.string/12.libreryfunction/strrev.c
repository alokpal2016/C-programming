char strrev(char s[]);
{

}
