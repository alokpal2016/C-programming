#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main()
{
    char *ptr[10];
    int n,i;
    printf("enter no of element to display:\n");
    scanf("%d",&n);
for(int i=0;i<n;i++)
  {
    ptr[i]=(char*)malloc(n*sizeof(char));
    printf("enter the string[%d]:",i+1);
    scanf("%s",ptr[i]);
  }
for(int i=0;i<n;i++)
  {
    printf("%d.string is:%s\n",(i+1),ptr[i]);
  }
}
