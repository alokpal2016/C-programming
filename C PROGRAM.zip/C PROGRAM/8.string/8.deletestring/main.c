#include<stdio.h>
#include<string.h>
#include"delete.h"
int main()
{
  char s1[10],s2[10];
  printf("enter the strings:\n");
  scanf("%s%s",&s1,&s2);
  delete(s1,s2);
}
