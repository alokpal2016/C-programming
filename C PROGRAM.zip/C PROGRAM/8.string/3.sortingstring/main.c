#include<stdio.h>
#include<string.h>
int main()
{
  char color[5][10]={
                       "white",
                       "red",
                       "green",
                       "blue",
                       "yellow"
  };
  int i,j;
  char temp[10];
  printf("string before sorting:\n");
  for(i=0;i<5;i++)
  {
    printf("%s   ",color[i]);
  }
  printf("\n");
  for(i=0;i<5;i++)
  {
    for(j=i+1;j<5;j++)
    {
     if(strcmp(color[i],color[j])>0)
     {
       strcpy(temp,color[i]);
       strcpy(color[i],color[j]);
       strcpy(color[j],temp);
     }
    }
  }
  printf("after sorting:\n");
  for(i=0;i<5;i++)
    printf("%s    ",color[i]);
  return 0;
}
