#include<stdio.h>
#include<string.h>
int main()
{
  char s[10],temp;
  int i=0,j=0,len;
  printf("enter the string for rotation:\n");
  scanf("%s",s);
  printf("the string is:\n%s\n",s);
  len=strlen(s);
  for(i=0;i<len-1;i++)
  {
    temp=s[0];
    for(j=0;j<len-1;j++)
    {
      s[j]=s[j+1];
    }
    s[len-1]=temp;
    printf("%s\n",s);
  }
}
