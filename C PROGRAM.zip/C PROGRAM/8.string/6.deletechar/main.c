#include<stdio.h>
#include<string.h>
#include"delete.h"

int main()
{
  char s[10],ch;
  printf("enter the string:\n");
  scanf("%s",s);
  printf("enter character which you want to delete from above string:\n");
  getchar();
  scanf("%c",&ch);
  delete(s,ch);
}
