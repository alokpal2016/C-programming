#include<stdio.h>
#include<string.h>
char delete(char s[],char ch)
{
  int i,len;
  len=strlen(s);
  for(i=0;i<len;i++)
  {
    if(s[i]==ch)
    {
          s[i]='\0';
    }
     printf("%c",s[i]);
  }
}
