char delete(char s[],char ch);
