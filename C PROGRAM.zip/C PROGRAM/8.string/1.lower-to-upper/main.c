#include<stdio.h>
#include<string.h>
void main()
{
  int i=0;
  char s[10],r[10];
  printf("enter the string:");
  gets(s);
while(s[i]!='\0')
{
  if(s[i]>='a'&& s[i]<='z')
    r[i]=s[i]-('a'-'A');
  else if(s[i]>='A'&& s[i]<='Z')
    r[i]=s[i]+('a'-'A');
  else
    r[i]=s[i];
    i++;
}
  printf("string after convertion=%s",r);
}
