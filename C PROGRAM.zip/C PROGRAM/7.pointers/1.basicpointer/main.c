#include<stdio.h>
int main()
{
  int x[8]={10,20,30,40,50,60,70,80},i;
  int *p;
  p=&x;
  //for(i=0;i<=7;i++)
  printf("meaning of x\t:%d",x);
  printf("\nmeaning of (x+2)\t:%d",x+2);
  printf("\nvelue of *x:%d",*p);
  printf("\nvelue of (*x+2):%d",*x+2);
  printf("\nvelue of *(x+2):%d",*(x+2));
}
