#include<stdio.h>
#include<string.h>
int main()
{
  char *s[]={"we will teach you how to","move a mountain","level a building","erase the past","make a million"};
  int count=0,i=0;
  char *sptr;
  sptr=s[i];
  while(i<5)
  {
  sptr=s[i];
  while(*sptr!='\0')
  {
    if(*sptr=='e' || *sptr=='E')
    {
      count++;
      *sptr++;
    }
    else
    {
      *sptr++;
    }
  }
  i++;
  }

  printf("\nno of 'e' char avilable in string is:%d",count);
  return 0;
//printf("\n");
}
