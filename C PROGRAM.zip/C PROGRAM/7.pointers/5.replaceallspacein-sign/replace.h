int replace(char *);
