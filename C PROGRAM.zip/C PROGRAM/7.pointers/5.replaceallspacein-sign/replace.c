#include<stdio.h>
#include<string.h>

int replace(char *ch)
{
char str[20];
  int count=0,i;
strcpy(str,ch);
 printf("the string after replacement is:");
  for(i=0;str[i]!='\0';i++)
  {
    if(str[i]==' ')
    {
    str[i]='-';
    count++;
    }
   printf("%c",str[i]);
  }
  printf("\n");
  return count;
}
