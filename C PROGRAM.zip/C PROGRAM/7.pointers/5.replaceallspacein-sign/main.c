#include<stdio.h>
#include"replace.h"
int main()
{
  int space; 
  char *cat="the cat sat";
  puts(cat);
 space=replace(cat);
  printf("the no of space is:%d\n",space);
}
