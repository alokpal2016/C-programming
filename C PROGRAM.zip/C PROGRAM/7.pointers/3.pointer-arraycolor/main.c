#include<stdio.h>
int main()
{
  char *color[6]={"red","blue","green","white","black","yellow"};
  printf("meaning of color:%p",color);
  printf("\nmeaning of color+2:%p",color+2);
  printf("\nvelue of *color:%s",*color);
  printf("\nvelue of *(color+2):%s",*(color+2));
  printf("\ndif between color[5]:%p and *(color+5):%s",color[5],*(color+5));
}
