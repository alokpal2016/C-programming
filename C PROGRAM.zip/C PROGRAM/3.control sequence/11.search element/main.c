#include<stdio.h>
void main()
{
	char element,a[10];
	int i;
	printf("Enter 8 elements\n");
	for(i=0;i<8;i++)
	{
		scanf("%c",&a[i]);
	}
	printf("Enter the element to be searched\n");
	scanf("%c",&element);
	for(i=0;i<9;i++)
	{
		if(element==a[i])
		{
			printf("Element found in location %d\n ",i);
			break;
		}
	}
	if(i==9)
	{
		printf("Element Not Found\n");
	}
}

