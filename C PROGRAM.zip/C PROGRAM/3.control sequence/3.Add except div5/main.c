#include<stdio.h>
void main()
{
	int n, sum=0, i;
	printf("Enter the No\n");
	scanf("%d",&n);
	for(i=n;i>0;i--)
	{
		if(i%5==0)
		continue;
		sum=sum+i;
	}
	printf("Sum=%d\n",sum);
}
