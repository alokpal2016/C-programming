#include<stdio.h>
void main()
{
	int n, i, sum=0;
	printf("Enter the No\n");
	scanf("%d",&n);
	i=1;
	while(i<=n)
	{
		if(i%2!=0)
		{
			sum+=i;
		}
		i++;
	}
	printf("Sum=%d\n",sum);
}
