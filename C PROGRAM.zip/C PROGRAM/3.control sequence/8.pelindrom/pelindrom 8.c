#include<stdio.h>
void main()
{
	int a,res,n,pal=0;
	printf("Enter the NO\n");
	scanf("%d",&a);
	n=a;
	while(n>0)
	{
		res=n%10;
		pal=pal*10+res;
		n=n/10;
	}	
	if(a==pal)
	printf("Palindrome\n");
	else
	printf("Not Palindrome\n");
}
