#include<stdio.h>
void main()
{
	char c;
	printf("Enter the charcter\n");
	scanf("%c",&c);
	if(c=='a'||c=='A')
	{
		printf("A for Apple\n");
	}
	else if(c=='b'||c=='B')
	{
		printf("B for Bat\n");
	}
	else if(c=='d'||c=='D')
	{
		printf("D for Dog\n");
	}
	else if(c=='f'||c=='F')
	{
		printf("F for Fan\n");
	}
	else
	{
		printf("Not in Range\n");
	}
	switch(c)
	{
		case 'a':
		case 'A':printf("A for Apple\n");
			 break;
		case 'b':
		case 'B':printf("B for Bat\n");
			 break;
		case 'd':
		case 'D':printf("D for Dog\n");
			 break;
		case 'f':
		case 'F':printf("F for Fan\n");
			 break;
		default: printf("Not in Range\n");
	}
}
