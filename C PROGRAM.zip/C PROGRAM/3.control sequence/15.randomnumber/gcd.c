int gcd(int m , int n)
{
	if(m>n)
	m=m-n;
	else
	n=n-m;
	if(n==m)
	return(n);
	else
	gcd(m,n);
}
