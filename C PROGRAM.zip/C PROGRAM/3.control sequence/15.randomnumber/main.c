#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int main()
{
  int i,j,prime,n;
  printf("ten rendom no in[1,100]\n");
  for(i=1;i<=10;i++)
  {
    n=rand()%100+1;
    printf("%d\n",n);
  }
  	//printf("Enter a NO except 0 and 1\n");
  	//scanf("%d",&n);
    printf("random  prime no:\n");
    n=100;
  	for(i=2;i<=n;i++)
  	{
  		prime=0;
  		for(j=2;j<=i/2;j++)
  		{
  			if(i%j==0)
  			{
  				prime=1;
  				break;
  			}
  		}
  		if(prime==0)
  		printf("%d\n",i);
    }
       //printf("Enter the No's except 0\n");
	     //scanf("%d%d",&a,&b);
       for(i=1;i<=10;i++)
       {
         for(j=1;j<=10;j++)
         {
	          gcd(i,j)==1;
		         printf(" Relatively Prime\n%d\t%d",i,j);
             break ;
		         printf("not Relatively Prime\n%d\t%d",i,j);
             break ;
          }
        }
      return 0;
}
