#include<stdio.h>
void main()
{
	int i,n,prime,j;
	printf("Enter a NO except 0 and 1\n");
	scanf("%d",&n);
	for(i=2;i<=n;i++)
	{
		prime=0;
		for(j=2;j<=i/2;j++)
		{
			if(i%j==0)
			{
				prime=1;
				break;
			}
		}
		if(prime==0)
		printf("%d\n",i);
		
	}
}
