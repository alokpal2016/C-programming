#include<stdio.h>
void main()
{
	int a,b,i,n;
	printf("Enter the No's except 0\n");
	scanf("%d%d",&a,&b);
	if(a%b==0||b%a==0)
	{
		printf("Not Relatively Prime\n");
	}
	else
	{
		printf("Relatively Prime\n");
	}
}
