#include<stdio.h>
void main()
{
	int r[10],h[10],i=0,j;
	float pay[10],total=0;
 	printf("Enter the rate and no of hours\n");
	do
	{
		scanf("%d%d",&r[i],&h[i]);
		if(r[i]==0)
		{
			break;
		}
		if(h[i]>60)
		{
			pay[i]=(h[i]-60)*2*r[i]+(float)20*1.5*r[i]+40*r[i];
		
		}
		else if(h[i]>40)
		{
			pay[i]=(float)(h[i]-40)*1.5*r[i]+40*r[i];

		}
		else
		{
			pay[i]=h[i]*r[i];
		}
		pay[i]=(float)pay[i]/100;
		total+=pay[i];
	i++;
	}
	while(1);
	for(j=0;j<i;j++)
	printf("Pay at %d pence an hour for %d hours is %.2f rupees\n",r[j],h[j],pay[j]);
	printf("Total Pay is %.2f\n",total);
}

		
		

