#include<stdio.h>
void main()
{
	int n, fact, i;
	printf("Enter the No\n");
	scanf("%d",&n);
	fact=1;
	for(i=1;i<=n;i++)
	{
		fact=fact*i;
	}
	printf("Factorial=%d\n",fact);	
}
		
	
