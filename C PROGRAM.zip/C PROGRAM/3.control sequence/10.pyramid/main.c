#include<stdio.h>
int main()
{
  int i,j,p,n=5;
  for(i=1;i<=5;i++)       /*loop for no of line in pyramid*/
  {
    for(j=1;j<=n-i;j++)   /*loop for print spaces*/
      printf(" ");
    p=i;
    for(j=1;j<=i;j++)     /*loop for print second part*/
      printf("%d",p--);
    p=1;
    for(j=1;j<=i-1;j++)   /*loop for print third part*/
      printf("%d",++p);
    printf("\n");         /*for print new line*/
  }
}
