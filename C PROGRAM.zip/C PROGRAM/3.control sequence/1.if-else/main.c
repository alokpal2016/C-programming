#include<stdio.h>
void main()
{
	int i,j;
	printf("Enter the No's");
	scanf("%d%d",&i,&j);
	if(i==20||j==20)
	{
		printf("At least 1 vriable is 20\n");
	}
	else
	{
		printf("Both the vriables are not 20\n");
	}
	if(i<=40&&j<=40)
	{
		printf("Both vriables are less than or equal to 40\n");
	}
	else
	{
		printf("Both the vriables are not less than or equal to 40\n");
	}
}


