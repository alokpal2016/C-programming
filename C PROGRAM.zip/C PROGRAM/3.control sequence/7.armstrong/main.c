#include<stdio.h>
void main()
{
	int a,sum=0,res,n;
	printf("Enter the NO\n");
	scanf("%d",&a);
	n=a;
	while(n>0)
	{
		res=n%10;
		sum+=res*res*res;
		n=n/10;
	}
	if(a==sum)
	printf("Armstrong\n");
	else
	printf("Not Armstrong\n");
}
