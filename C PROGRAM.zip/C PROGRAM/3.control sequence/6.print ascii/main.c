#include<stdio.h>
void main()
{
	char c;
	int asc;
	printf("Enetr the char\n");
	scanf("%c",&c);
	asc=c;
	printf("Ascii vaule of %c is %d\n",c,c);
}
	
