#include<stdio.h>
int sum,pro;
void fun(void);
void sumpro(int a,int b);
int main()
{
auto int a=10;
auto int b=30;
{
	register int a=20;
		
	{
		printf("a1=%d\n",a);
	}
	printf("a2=%d\n",a);
	sumpro(a,b);
	printf("sum1=%d\npro1=%d\n",sum,pro);
}

printf("a3=%d\n",a);
sumpro(a,b);
printf("sum2=%d\npro2=%d\n",sum,pro);
fun();
fun();
fun();

return 0;
}


void fun()
{
static int a=1;
printf("a4=%d\n",a);
a++;
}


void sumpro(int a,int b)
{
sum = a+b;
pro = a*b;
}

