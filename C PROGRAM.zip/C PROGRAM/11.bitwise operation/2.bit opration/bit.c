#include <stdio.h>
void displaybits(int);
int main()
{
  int a= 0xa2c3;

  printf("a= 0x%x\n",a ); displaybits(a);
  printf("~a= ox%x\n",~a ); displaybits(~a);
  printf("a ^ 0x3f06= 0x%x\n",a ^ 0x3f06 ); displaybits(a ^ 0x3f06);
  printf("a | 0x3f06= 0x%x\n",a | 0x3f06 ); displaybits(a | 0x3f06);
  printf("a | ~0x3f06= 0x%x\n",a | ~0x3f06 ); displaybits(a | ~0x3f06);
  printf("a >> 3= 0x%x\n",a >> 3 ); displaybits(a >> 3);
  printf("a << 5= 0x%x\n",a << 5 ); displaybits(a << 5);
  printf("a ^ ~a= 0x%x\n",a ^ ~a ); displaybits(a ^ ~a);
  printf("a | ~a= 0x%x\n",a | ~a ); displaybits(a | ~a);
  printf("(a & ~0x3f06) << 8= 0x%x\n",(a & ~0x3f06) << 8 ); displaybits((a & ~0x3f06) << 8);
  printf("a & ~ (0x3f06 >> 8)= 0x%x\n",a & ~ (0x3f06 >> 8) ); displaybits(a & ~ (0x3f06 >> 8));

  return 0;
}
void displaybits(int num)
{
  int i,mask;
  for (i = 31; i >=0; i--)
  {
    mask=1<<i;
    putchar((num&mask)?'1':'0');
    if (i%8==0)
    putchar(' ');
  }
  printf("\n" );
}
