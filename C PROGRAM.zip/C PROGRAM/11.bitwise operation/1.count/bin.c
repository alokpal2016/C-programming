void binary(int num)
{
  int rem,bin=0,conv=1,coun=0;
  while (num>0)
  {
    rem=num%2;
    num=num/2;
    bin=bin+rem*conv;
    if (rem==1)
    {
      coun++;
    }
    conv=conv*10;


  }
  printf("Binary convertion of given number is: %d\nAnd 1's in number is: %d\n",bin,coun);
}
