#include <stdio.h>
void binary(int);
int main()
{
  int num;
  printf("Enter the decimal number: ");
  scanf("%d",&num);
  binary(num);

  return 0;
}
