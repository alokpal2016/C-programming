int mod(int a, int b)
{
	return a%b;
}
