#include<math.h>
int div(int a, int b)
{
	int c;
	c= a/b;
	printf("C=%d\n",c );
	return c;
}
