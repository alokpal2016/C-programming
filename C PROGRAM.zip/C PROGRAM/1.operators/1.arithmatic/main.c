#include<stdio.h>
#include<math.h>
void main()
{
	int a,b;
	printf("Enter the values of a and b\n");
	scanf("%d%d",&a,&b);
	printf("Sum=%d\nSub=%d\nMul=%d\ndiv=%d\nMod=%d\n%f",add(a,b),sub(a,b),mul(a,b),div(a,b),mod(a,b),d);
}
