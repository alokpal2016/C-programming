#include<stdio.h>
void main()
{
  int a,b,c;
  printf("Eneter the nos\n");
  scanf("%d%d",&a,&b);
  c=addop(a,b);
  printf("Sum=%d\n",c);
}
