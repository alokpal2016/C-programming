#include<stdio.h>
int main()
{
  int a,ia,b,ib,c,ic,sum,isum,sub,isub,mul,imul;
  printf("Enter 2 complex no's\n");
  scanf("%d%d%d%d",&a,&ia,&b,&ib);
  sum=a+b;
  isum=ia+ib;
  sub=a-b;
  isub=ia-ib;
  mul=a*b-ia*ib;
  imul=a*ib+b*ia;
  printf("Sum=%d %di\nSub=%d %di\nMul=%d %di\n",sum,isum,sub,isub,mul,imul);
  return 0;
}
