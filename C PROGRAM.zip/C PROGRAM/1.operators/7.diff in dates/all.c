int all(int a, int b, int c, int m[])
{
  int t,i=0;
  t=a;
  if(c%4==0)
  {
    if(c%100==0)
    {
      if(c%400==0)
      {
        if(b>2)
        t+=1;
      }
      goto l;
    }
    if(b>2)
    t+=1;
  }
l:while(i<b-1)
  {
    t+=m[i];
    i++;
  }
  c=c-1;
  t+=(c/4-c/100+c/400)*366+(c-(c/4-c/100+c/400))*365;
  return t;
}
