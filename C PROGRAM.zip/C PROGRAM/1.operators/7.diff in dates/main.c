#include<stdio.h>
main()
{
  int d1,m1,y1,d2,m2,y2,m[12]={31,28,31,30,31,30,31,31,30,31,30,31},total1,total2,total;
  printf("Enter the dates in dd/mm/yy format\n");
  scanf("%d%d%d%d%d%d",&d1,&m1,&y1,&d2,&m2,&y2);
  total1=all(d1,m1,y1,m);
  total2=all(d2,m2,y2,m);
  total=total1-total2;
  printf("Difference=%d\n",total);
}
