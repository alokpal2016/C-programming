#include<stdio.h>
int main()
 {
  int a,b,maximum;
  printf("Enter the 2 No's\n");
  scanf("%d%d",&a,&b);
  maximum=max(a,b);
  printf("Maximum=%d\n",maximum);
  return 0;
}
