#include<stdio.h>
int main()
{
  unsigned int x=0x79777889;
  char *c=(char*)&x;
  printf("*c=0x%x\n,*c");
    if(*c==0x89)
    {
      printf("\tenter no is little endian\n",*c);
    }else
    {
      printf("enter no is big endian\n",*c);
    }
    return 0;
}
