void addmat(int a[][10], int b[][10], int c[][10], int r, int co)
{
  int i,j;
  for(i=0;i<r;i++)
  {
    for(j=0;j<co;j++)
    {
      c[i][j]=a[i][j]+b[i][j];
    }
  }
}
