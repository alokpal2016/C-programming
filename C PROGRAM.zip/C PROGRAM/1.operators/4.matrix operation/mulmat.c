void mulmat(int a[][10], int b[][10], int c[][10], int r, int co)
{
  int i,j,k;
  for(i=0;i<r;i++)
  {
    for(j=0;j<co;j++)
    {
      c[i][j]=0;
      for(k=0;k<co;k++)
      {
        c[i][j]+=a[i][k]*b[k][j];
      }
    }
  }
}
