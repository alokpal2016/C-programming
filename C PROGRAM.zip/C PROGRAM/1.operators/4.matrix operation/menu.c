int menu()
{
  int c;
  printf("Press 1 for ADDITION\nPress 2 for SUBSTRACTION\nPress 3 for MULTIPLICATION");
  scanf("%d",&c);
  return c;
}
