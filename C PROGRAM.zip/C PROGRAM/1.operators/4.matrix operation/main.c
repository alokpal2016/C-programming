#include<stdio.h>
int row,col;
int main()
{
  int a[10][10],b[10][10],c[10][10],r1,c1,r2,c2,d;
  printf("Enter the order of 1st matrix\n");
  scanf("%d%d",&r1,&c1);
  readmat(a,r1,c1);
  printmat(a,r1,c1);
  printf("Enter the order of 2nd matrix\n");
  scanf("%d%d",&r2,&c2);
  readmat(b,r2,c2);
  printmat(b,r2,c2);
  d=menu();
  switch(d)
  {
    case 1: addmat(a,b,c,r1,c1);
            printmat(c);
            break;
    case 2: submat(a,b,c,r1,c1);
            printmat(c);
            break;
    case 3: mulmat(a,b,c,r1,c2);
            printmat(c);
            break;
    default:  printf("INVALID");
  }
  return 0;
}
