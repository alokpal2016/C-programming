#include<stdio.h>
#include <stdio_ext.h>
int swap(int *a,int *b)
{
  int temp;
  temp=*a;
  *a=*b;
  *b=temp;
}
void main()
{
  int a,b;
  int *p,*q;
  p=&a,q=&b;
  printf("before swaping velue of a and b is:");
  scanf("%d%d",&a,&b);
  swap(p,q);
  printf("after swaping:%d\t%d",*p,*q);

}
