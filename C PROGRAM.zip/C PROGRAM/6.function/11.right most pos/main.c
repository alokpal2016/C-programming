#include<stdio.h>
int indexr(char s[10] , char t)
{
	int i=0,pos=-1,j=0;
	while((s[i]>='a' && s[i]<='z')||(s[i]>='A' && s[i]<='Z'))
	{
		j++;
		printf("%d",s[i]);
		i++;
	}
	for(i=0;i<j;i++)
	{
		printf("%c",s[i]);
		if(s[i]==t)
		pos=i;
		printf("%d",pos);
	}
	return(pos);
}
void main()
{
	char s[10],t;
	int pos,i=0;
	printf("Enter the string\n");
	while(s[i]!='\n')
	{
		i++;
		t=getchar();
		s[i]=t;
		
	}
	printf("Enter the char to be searched\n");
	t=getchar();
	pos=indexr(s,t);
	printf("Index=%d\n",pos);
}
		
