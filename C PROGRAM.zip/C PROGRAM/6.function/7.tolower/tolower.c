
char tolower(char ch[])
{
  int i;
  for(i=0;ch[i]!='\0';i++)
  if(ch[i]>='A' && ch[i]<='Z')
  ch[i]+=32;
}
