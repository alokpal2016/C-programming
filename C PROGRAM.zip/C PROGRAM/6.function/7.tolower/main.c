#include<stdio.h>
#include"tolower.h"
void main()
{
  char name[10],ch;
  int i=0,k;
  printf("enter your name:");
  gets(name);
  printf("the name is:%s\n",name);
  tolower(name);
  printf("name after convertion is:%s",name);
}
