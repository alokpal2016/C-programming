#include<stdio.h>
void transpose(int a[][10] , int r , int c)
{
	int trans[10][10],i,j;
	for(i=0;i<c;i++)
	{
		for(j=0;j<r;j++)
		{
			trans[i][j]=a[j][i];
		}
	}
	printf("The transpose matrix is\n");
	for(i=0;i<c;i++)
	{
		for(j=0;j<r;j++)
		{
			printf("%d ",trans[i][j]);
		}
		printf("\n");
	}
}
void main()
{
	int a[10][10],r,c,i,j;
	printf("Enter the order of the matrix:");
	scanf("%d%d",&r,&c);
	printf("Enter the matrix\n");
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	transpose(a,r,c);

}
