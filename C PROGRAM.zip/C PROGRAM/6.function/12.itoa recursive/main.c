#include<stdio.h>
int itoa(int q )
{
	int i=0,res,b=1;
	char c[10];
	while(q>0)
	{
		res=q%10;
		b=b*10+res;
		q=q/10;
	}
	while(b>0)
	{
		res=b%10;
		if(res==0)
		c[i]='0';
		else if(res==1)
		c[i]='1';
		else if(res==2)
		c[i]='2';
		else if(res==3)
		c[i]='3';
		else if(res==4)
		c[i]='4';
		else if(res==5)
	        c[i]='5';				
		else if(res==6)
		c[i]='6';		
		else if(res==7)
		c[i]='7';
		else if(res==8)
		c[i]='8';
		else 
		c[i]='9';
		b=b/10;
		i++;
	}
	reverse(c,i);	
}
void reverse(char c[] , int i)
{
	int j;
	printf("The string is ");
	for(j=0;j<i-1;j++)
	{
		printf("%c",c[j]);
	}
	printf("\n");
}
void main()
{
	int n;
	printf("Enter the no");
	scanf("%d",&n);
	itoa(n);
}
