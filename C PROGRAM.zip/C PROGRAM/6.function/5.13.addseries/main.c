#include<stdio.h>
int fact(int y)
{
	int f=1;
	if(y!=0)
	f=y*fact(y-1);
	return(f);
}
float series(int i)
{
  float res;
  float s=0;
  while(i!=0)
    {
			res=(float)i/fact(i);
			s=(float)(s+res);
      i--;
    }
	return ((float)s);
}
void main()
{
	int n;
	float z;
	printf("Enter the length of the series\n");
	scanf("%d",&n);
	z=(float)series(n);
	printf("Sum=%.2f\n",z);
}
