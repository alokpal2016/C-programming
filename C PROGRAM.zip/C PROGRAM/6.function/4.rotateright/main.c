#include<stdio.h>
int rotate_right(int x , int y)
{
	int n=x,div=1,res;
	while(x>9)
	{
		x=x/10;
		div=div*10;
	}
	x=n;
	while(y!=0)
	{
		res=n%10;
		n=n/10;
		n=res*div+n;
		y--;
	}
	return(n);
}
void main()
{
	int n,b,f;
	printf("Enter n&b\n");
	scanf("%d%d",&n,&b);
	f=rotate_right(n,b);
	printf("Result=%d",f);
}
