#include<stdio.h>
int fact(int i)
{
  	int f=1;
	while(i!=1)
	{
		f=f*i;
		i--;
	}
	return(f);
}
int main()
{
	int n,r;
	float a,b;
	printf("enter the numbers ");
	scanf("%d%d",&n,&r);
	a=(float)fact(n)/fact(n-r);
  b=(float)fact(n)/(fact(n-r)*fact(r));
	printf("nPr=%.2f\tnCr=%.2f\n",a,b);
}
