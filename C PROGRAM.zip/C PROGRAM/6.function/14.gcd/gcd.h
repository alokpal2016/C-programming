int fact(int );
int gcd(int ,int);
