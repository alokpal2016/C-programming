#include<stdio.h>
#include"gcd.h"
int main()
{
  int a,b,n,f,g;
  printf("enter the velues:");
  scanf("%d%d%d",&a,&b,&n);
  f=fact(n);
  printf("the factorial is:%d\nthe gcd is:%d",f,gcd(a,b));
}
