#include<stdio.h>
#include"calculater.h"

int menu(int c,int a,int b,int n)
{
    int i;
    float d;
  	switch(c)
  	{
  		case 1:
  			multiplication(a,b);
        printf("multiplication=%d\n",multiplication(a,b));
  			break;
  		case 2:
  			 d=div(a,b);
        printf("div=%f\n",d);
  			break;
  		case 3:
  			squre(n);
          printf("squre=%d\n",squre(n));
  			break;
  		case 4:
  			if(n<0)
  			break;
  			i=fact(n);
  			printf("Factorial=%d\n",i);
  			break;
  		default:printf("Invalid Input\n");
  	}
  }
