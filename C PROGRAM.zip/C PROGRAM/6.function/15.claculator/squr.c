int squre(int n)
{
  return n*n;
}
