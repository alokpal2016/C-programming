#include <stdio.h>

float div(int a,int b)
{
  float c;
  if(a>b)
  c=(float)a/(float)b;
  else
  c=(float)b/(float)a;
  return c;
}
