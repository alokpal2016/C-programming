int gcd(int a,int b)
{
 while(a!=b)
  {
    if(a>b)
    {
     return (a-b,b);
    }
    else
    {
    return (a,b-a);
    }
  }
}
