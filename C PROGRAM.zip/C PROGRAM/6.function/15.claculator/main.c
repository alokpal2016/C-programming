#include<stdio.h>
#include"calculater.h"
int main()
{
  int a,b,n,c;
  printf("enter the velues:");
  scanf("%d%d%d",&a,&b,&n);
  printf("1.mul\n2.Div\n3.squr\n4.Factorial\n");
  scanf("%d",&c);
  menu(c,a,b,n);
  multiplication(a,b);
  div(a,b);
  fact(n);
  squre(n);
  main();

}
