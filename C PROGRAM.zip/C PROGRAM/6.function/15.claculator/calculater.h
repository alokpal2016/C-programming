int menu(int,int,int,int);
int multiplication(int ,int );
int div(int ,int );
int squre(int );
int fact(int );
