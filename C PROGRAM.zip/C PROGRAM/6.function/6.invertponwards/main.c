#include<stdio.h>
int pow(int a , int b)
{
	int res=1;
	while(b!=0)
	{
		res=res*a;
		b--;
	}
	return(res);
}
int invertponwards(int n , int p , int b)
{
	int rev=0,res1=0,res2=0,q=n,t=1,z,x,i;
	while(q>0)
	{
		res1=q%10;
		rev=rev*10+res1;
		q=q/10;
	}	
	q=n;
	while(q>9)
	{
		q=q/10;
		t++;
	}
	q=n;
	i=t;
	while(i>p)
	{
		z=rev%10;
		res2=res2*10+z;
		rev=rev/10;
		i--;
	}
	
	if(i==p)
	{
		q=pow(10,b);
		x=rev%q;
		res2=res2*q+x;
		i=i-b;
		rev=rev/q;
	}
	while(i>0)
	{
		z=rev%10;
		res2=res2*10+z;
		rev=rev/10;
		i--;
	}
	return(res2);
}
void main()
{
	int n,p,b,res;
	printf("Enter the values\n");
	scanf("%d%d%d",&n,&p,&b);
	res=invertponwards(n,p,b);
	printf("Result=%d\n",res);
}
	

		
		
		
			
						
			
		
		
		
