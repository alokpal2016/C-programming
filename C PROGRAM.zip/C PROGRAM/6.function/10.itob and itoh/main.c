#include<stdio.h>
int itob(int b )
{
	int i=0,res;
	char c[10];
	while(b>0)
	{
		res=b%2;
		if(res==1)
		c[i]='1';
		else
		c[i]='0';
		b=b/2;
		i++;
	}	
	reverse(c,i);
}
int itoh(int b)
{
	char c[10];
	int res,i=0,j;
	while(b>0)
	{
		res=b%16;
		if(res>=10)
		{
			switch(res)
			{
				case 10:c[i]='A';
					b=b/10;
					i++;
					break;
				case 11:c[i]='B';
					b=b/10;
					i++;
					break;
				case 12:c[i]='C';
					b=b/10;
					i++;
					break;
				case 13:c[i]='D';
					b=b/10;
					i++;
					break;
				case 14:c[i]='E';
					b=b/10;
					i++;
					break;
				case 15:c[i]='F';
					b=b/10;
					i++;
					break;
			}
		}
		else
		{
			if(res==0)
			c[i]='0';
			else if(res==1)
			c[i]='1';
			else if(res==2)
			c[i]='2';
			else if(res==3)
			c[i]='3';
			else if(res==4)
			c[i]='4';
			else if(res==5)
		        c[i]='5';				
			else if(res==6)
			c[i]='6';		
			else if(res==7)
			c[i]='7';
			else if(res==8)
			c[i]='8';
			else 
			c[i]='9';
			b=b/10;
			i++;
		}
		
	}
	reverse(c,i);
}
void reverse(char c[] , int i)
{
	char a[10];
	int j;

	for(j=0;j<i;j++)
	{
		a[j]=c[i-j];
	}
	printf("The string is ");
	for(j=0;j<i;j++)
	{
		printf("%c",a[j]);
	}
	printf("\n");
}
void main()
{
	int n;
	printf("Enter the no");
	scanf("%d",&n);
	itob(n);
	itoh(n);
}

	


		
