#include<stdio.h>
int fact(int i)
{
  	int f=1;
	while(i!=1)
	{
		f=f*i;
		i--;
	}
	return(f);
}
main()
{
	int n,r;
	float a;
	printf("enter the numbers ");
	scanf("%d%d",&n,&r);
	a=(float)fact(n)/fact(n-r);
	printf("Result=%.2f\n",a);
}
	
