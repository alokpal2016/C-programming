 #include<stdio.h>
int fact(int i)
{
  int f=1;
  if(i!=0)
  f=i*fact(i-1);
  return(f);
}
void main()
{
  int n,fac;
  printf("enter the no for factorial:");
  scanf("%d",&n);
  fac=fact(n);
  printf("\nthe factorial is%d\n",fac);
}
