#include<stdio.h>
#include<stdlib.h>
void main()
{
	int n,sum=0,*ptr,i;
	printf("Enter the no of elements:	");
	scanf("%d",&n);
	ptr=(int*)malloc(n*sizeof(int));
	if(ptr==NULL)
	{
		printf("Memory not allocated ");
	}
	printf("Enter the elements ");
	for(i=0;i<n;i++)
	{
		scanf("%d",ptr+i);	
	}
	printf("The elements are ");
	for(i=0;i<n;i++)
	{
		printf("%d ",*(ptr+i));	
	}
	free(ptr);
}
