#include<stdio.h>
void main()
{
	char name[10],ch;
	int i=0,j;
	printf("Enter your name\n");
	while(1)
	{
		ch=getchar();
		name[i]=ch;
		if(name[i]=='\n')
		break;
		i++;
	}
	for(j=0;j<i;j++)
	{
		printf("%c",name[j]);
	}

	printf("\nLength is %d\n",i);
	printf("The Size of the array is %d\n",sizeof(name));
}
