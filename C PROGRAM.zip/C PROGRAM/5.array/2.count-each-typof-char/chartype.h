int countchar(char[]);
