#include<stdio.h>
#include"chartype.h"
int main()
{
  char str[80];
  printf("enter the string:");
  gets(str);
  puts(str);
  countchar(str);
}
