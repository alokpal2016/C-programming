#include<stdio.h>
void countchar(char ch[])
{
  int character=0,tab=0,digits=0,blanks=0,special=0;
  int i;
  for(i=0;ch[i]!='\0';i++)
  {
    if((ch[i]>='A' && ch[i]<='Z') || (ch[i]>='a' && ch[i]<='z'))
    {
      character++;
    }
    else if(ch[i]=='\t')
    {
      tab++;
    }
    else if(ch[i]>='0' && ch[i]<='9')
    {
      digits++;
    }
    else if((ch[i]>='!' && ch[i]<='/') || (ch[i]>=':' && ch[i]<='@') || (ch[i]>='{' && ch[i]<='~'))
		{
			special++;
		}
    else if(ch[i]==' ')
    {

      blanks++;
    }
  }
  printf("Characters=%d\ntab=%d\ndigits=%d\nBlank=%d\nspecial=%d\n",character,tab,digits,blanks,special);
}
