#include<stdio.h>
#include<string.h>
struct desd
{
	int a,b,c;
	char name[10];
};
struct dssd
{
	int a,b,c;
	char name[10];
};
struct dac
{
	int a,b,c;
	char name[10];
};
void main()
{
	struct desd a[50];
	struct dssd b[50];
	struct dac c[50];
	int x,y,z,i,j;
	printf("Enter the no. of students in desd, dssd and dac\n");
	scanf("%d%d%d",&x,&y,&z);
	j=0;
	for(i=1;i<=x;i++)
	{
		printf("Enter the name of %d student in DESD:",i);
		scanf("%s",&a[i].name);
		printf("Enter the marks:");
		scanf("%d%d%d",&a[i].a,&a[i].b,&a[i].c);
	}
	j=0;
	for(i=1;i<=y;i++)
	{
		printf("Enter the name of %d student in DSSD:",i);
		scanf("%s",&b[i].name);
		printf("Enter the marks:");
		scanf("%d%d%d",&b[i].a,&b[i].b,&b[i].c);
	}
	j=0;
	for(i=1;i<=z;i++)
	{
		printf("Enter the name of %d student in DAC:",i);
		scanf("%s",&c[i].name);
		printf("Enter the marks:");
		scanf("%d%d%d",&c[i].a,&c[i].b,&c[i].c);
	}
	printf("The marks of DESD students are\n");
	for(i=1;i<=x;i++)
	{
		printf("%d. %s %d %d %d",i, a[i].name,a[i].a,a[i].b,a[i].c);
		printf("\n");
	}
	printf("The marks of DSSD students are\n");
	for(i=1;i<=y;i++)
	{
		printf("%d. %s %d %d %d",i, b[i].name,b[i].a,b[i].b,b[i].c);
		printf("\n");
	}
	printf("The marks of DAC students are\n");
	for(i=1;i<=z;i++)
	{
		printf("%d. %s %d %d %d",i, c[i].name,c[i].a,c[i].b,c[i].c);
		printf("\n");
	}
}
