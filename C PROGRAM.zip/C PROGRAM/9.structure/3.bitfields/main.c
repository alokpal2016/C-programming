#include<stdio.h>
struct example{
  char a;

  int  d[10];  char b;
}ab;
void main()
{

  printf("\n size of struct %d\t%d\t%d\t",sizeof(ab),sizeof(ab.a),sizeof(ab.d));
}
