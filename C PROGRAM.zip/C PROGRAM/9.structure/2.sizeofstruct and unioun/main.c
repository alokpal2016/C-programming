#include <stdio.h>
struct sample1
{
	int	a;
	char	b;
};
union sample2
{
	int	a;
	char	b;
};
void main()
{
	struct sample1 a;
	union sample2 b;
	int c,d;
	c=sizeof(a);
	d=sizeof(b);
	printf("Struct=%d Union=%d\n",c,d);
} 
