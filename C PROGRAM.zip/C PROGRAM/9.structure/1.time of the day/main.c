#include <stdio.h>
struct time
{
	int	h,m,s;
};
void main()
{
	struct time a;
	printf("Enter the time\n");
	scanf("%d%d%d",&a.h,&a.m,&a.s);
	printf("The time is %d:%d:%d\n",a.h,a.m,a.s);
}
